# WonderCave — Design, Data & Platform Overhaul

A comprehensive overhaul of WonderCave delivering a sharp architectural zero-border-radius aesthetic, Google Sheets database integration with sync endpoints, fix for missing post and route bodies, minimal HTTP status pages (404 and 301), Poppins typography, flat neutral gray canvases with zero gradients, and official site management credits.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed during the clarification interview:
> - **Database Strategy**: Google Sheets sync via public published CSV / Webhook endpoint with resilient JSON caching so the site remains operational offline and in all deployment environments.
> - **Visual Aesthetics**: Clean neutral gray with zero border-radius (`rounded-none` / `--radius: 0px`) across all cards, buttons, inputs, modals, and images, with flat panels and all gradients eradicated.
> - **Attribution & Domain Placement**: Dedicated footer attribution and copyright section: `wondercave.nayem.net · Site managed by Nayem Hasan`.

- **Confirmed Decision 1**: Zero border-radius (`0px`) applied globally via Tailwind configuration, CSS variables, and component overrides (`rounded-none`).
- **Confirmed Decision 2**: Poppins loaded via Google Fonts as the universal font family for headings, body, and UI elements.
- **Confirmed Decision 3**: Dedicated minimal 404 (Not Found) and 301 (Moved Permanently with countdown and manual redirect) pages.
- **Confirmed Decision 4**: Missing post bodies fixed by adding comprehensive slug-matching, parent-route fallback, and rich markdown content for all navigation endpoints in both `data/pages.json` and Google Sheet sync.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the WonderCave web portal into a razor-sharp, high-performance educational and enterprise solutions platform. Content is powered by a free Google Sheets database with real-time sync capabilities, instant page rendering, and zero layout breakage.
- **Target Audience / Persona**: Enterprise security teams, developers, cybersecurity researchers, and students seeking hands-on labs, vulnerability research, and enterprise tooling.
- **Key Value**: A fast, bug-free, zero-gradient interface with sharp brutalist/architectural precision, instant loading of all articles and lab topics, and seamless content management via Google Sheets.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Browsing Modules & Posts**: Users navigate to any topic (e.g., `/products/vulnerability-scanner`, `/topics/cross-site-scripting`, `/solutions/manufacturing`), instantly receiving rich markdown bodies, structured syllabus, code snippets, and high-definition photography without empty card states.
2. **Redirect & Error Navigation**: Navigating to moved or legacy URLs lands on a clean, minimal 301 redirect page with automatic destination routing, while non-existent routes render a sharp, minimal 404 page with navigation breadcrumbs.
3. **Database Syncing & Content Management**: The backend can pull published content directly from a Google Sheet CSV endpoint or manual sync trigger, keeping the site up to date without code redeployment.

### Visual Identity & Theme
- **Zero Border-Radius**: All elements (`button`, `card`, `input`, `badge`, `modal`, `img`) have `border-radius: 0px !important`.
- **Typography**: Universal `Poppins` (weights 400, 500, 600, 700) loaded globally from Google Fonts; monospace numbers for metrics and code blocks.
- **Color Palette & Gray Tone**:
  - Dominant Canvas: Neutral cool gray (`#E9ECEF` / `#F1F3F5` in light mode, `#1A1D21` in dark mode).
  - Structural Cards: Crisp flat surfaces (`#FFFFFF` in light mode, `#22262C` in dark mode) with 1px solid hairline borders (`#D0D5DD` / `#343B44`), zero box shadows, and zero gradients.
  - Accent Tone: High-intent sharp indigo/blue (`#1E40AF` or `#0F172A`) for primary interactive controls.
- **No Gradients**: All `bg-gradient-to-*` classes and gradient backgrounds are replaced with solid flat architectural colors.
- **Footer Attribution**: Clean, unboxed text row at the bottom of the page:
  `wondercave.nayem.net — Site managed by Nayem Hasan © 2026. All rights reserved.`

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Google Sheets as the Free Database**
  - *Chosen Approach*: The backend server (`server.ts`) implements a Google Sheets CSV parser and sync endpoint (`/api/sync-sheets`), supporting both public Google Sheets published as CSV (`https://docs.google.com/spreadsheets/d/{SHEET_ID}/pub?output=csv`) and fallback local caching in `data/pages.json`.
  - *Why*: Eliminates expensive database hosting fees while giving content editors an intuitive, familiar spreadsheet interface to update page titles, subtitles, markdown bodies, and images.
  - *Alternatives Considered*: Direct Google Sheets API via OAuth (requires user login and credential renewal, unnecessarily complex for public reading).

- **Decision 2: Universal Zero Radius Discipline**
  - *Chosen Approach*: Enforce `--radius: 0px` in `src/index.css`, override `@theme` radius scale to `0px`, and remove all `rounded-*` classes across components (`rounded-none`).
  - *Why*: Strict adherence to the user's design constraint, giving the entire portal a cohesive, modern technical aesthetic.

- **Decision 3: Dedicated 301 & 404 Minimal Status Pages**
  - *Chosen Approach*: Build lightweight, purpose-built `NotFound.tsx` (404) and `RedirectPage.tsx` (301) components with clean typography, HTTP status indicators, clear navigation paths, and automated countdown redirects.
  - *Why*: Meets the request for minimal code status pages while providing immediate user orientation and search engine friendliness.

---

## 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────┐
│                    Google Sheets Database                    │
│   (Published CSV / Webhook with Page & Post Records)         │
└──────────────────────────────┬───────────────────────────────┘
                               │ HTTP GET /sync-sheets
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                 Express Backend (server.ts)                  │
│  - /api/pages (merged Google Sheet cache + seed content)     │
│  - /api/sync-sheets (triggers live reload from sheet URL)    │
│  - /api/products, /api/leaderboard, /api/announcement        │
└──────────────────────────────┬───────────────────────────────┘
                               │ JSON REST API
                               ▼
┌──────────────────────────────────────────────────────────────┐
│                   React 19 SPA (Vite)                        │
│  - Poppins Universal Typography & Zero Border-Radius         │
│  - GenericContentPage.tsx (Nested slug resolver & Markdown)  │
│  - RedirectPage.tsx (301 minimal) & NotFound.tsx (404)       │
│  - Footer with wondercave.nayem.net & Nayem Hasan credit     │
└──────────────────────────────────────────────────────────────┘
```

### Route & Content Mapping
- Every route in the header, footer, and home page (such as `/products/enterprise`, `/solutions/manufacturing`, `/topics/cross-site-scripting`) maps dynamically through `GenericContentPage.tsx`.
- The slug resolver handles multi-segment paths (e.g., `products/vulnerability-scanner` matching either the full path key or leaf key), providing complete markdown bodies so no page appears empty or missing text.
